package com.ecommerce.app.service;

import java.util.List;

import com.ecommerce.app.entity.Product;

public interface ProductService {

	List<Product> getProductsList();

	List<Product> getProductsByName(String productName);

}
