/**
 * 
 */
package com.ecommerce.app;

/**
 * @author adminmx
 *
 */
public class AdminController {

}
